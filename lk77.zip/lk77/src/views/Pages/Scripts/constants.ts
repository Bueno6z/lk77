export const BASE_WINDOW_HEIGHT = 880;
export const BASE_WINDOW_WIDTH = 1824;
export const BASE_PADDING = 48;
